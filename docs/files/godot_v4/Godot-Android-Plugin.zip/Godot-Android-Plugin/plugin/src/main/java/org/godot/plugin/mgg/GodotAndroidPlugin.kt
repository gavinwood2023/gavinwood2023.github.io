// TODO: Update to match your plugin's package name.
package org.godot.plugin.mgg

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.telephony.TelephonyManager
import android.text.TextUtils
import android.util.Log
import android.widget.Toast
import org.godotengine.godot.Godot
import org.godotengine.godot.plugin.GodotPlugin
import org.godotengine.godot.plugin.UsedByGodot


class GodotAndroidPlugin(godot: Godot): GodotPlugin(godot) {

    override fun getPluginName() = BuildConfig.GODOT_PLUGIN_NAME;

    @UsedByGodot
    private fun showToast(str: String) {
        runOnUiThread {
            Toast.makeText(activity, str, Toast.LENGTH_LONG).show()
            Log.v(pluginName, str)
        }
    }

    @UsedByGodot
    private fun getMcc(): Int {
        var mcc = -1
        val telephonyManager = activity?.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
        val networkOperator = telephonyManager.networkOperator
        if (!TextUtils.isEmpty(networkOperator)) {
            mcc = networkOperator.substring(0, 3).toInt()
        }
        Log.i("NetworkOperatorMCC:", "" + mcc)
        return mcc
    }

    @UsedByGodot
    private fun copyStr2Clipboard(str: String){
        var clipManager = activity?.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager;
        val myClip = ClipData.newPlainText("text", str)
        clipManager.setPrimaryClip(myClip)
    }

    @UsedByGodot
    private fun getStr4Clipboard(): String{
        var result = "";
        var clipboardManager = activity?.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager;
        // 检查剪贴板是否有内容
        if (clipboardManager.hasPrimaryClip()) {
            // 获取剪贴板的内容
            val clip = clipboardManager.primaryClip
            // 确保剪贴板内容不为空且有至少一条剪贴板内容
            if (clip != null && clip.itemCount > 0) {
                // 获取第一条剪贴板内容
                val clipItem = clip.getItemAt(0)
                // 将剪贴板内容转换为字符串
                val clipText = clipItem.text?.toString()
                // 判断剪贴板内容是否为空
                if (clipText.isNullOrEmpty()) {
                    println("剪贴板内容为空")
                } else {
                    result = clipText;
                }
            } else {
                println("剪贴板为空或无内容")
            }
        }
        return result;
    }

}
